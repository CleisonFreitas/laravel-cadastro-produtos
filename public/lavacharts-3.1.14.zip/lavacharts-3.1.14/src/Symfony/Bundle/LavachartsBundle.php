<?php

namespace Khill\Lavacharts\Symfony\Bundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class LavachartsBundle extends Bundle
{
    //
}
