#### What Version?
> Run `composer show khill/lavacharts` if you don't know


#### Issue
> Please describe the issue. 


#### Controller Code (chart creation code)
```
// paste over this
```


#### View Code
```
// paste over this
```
